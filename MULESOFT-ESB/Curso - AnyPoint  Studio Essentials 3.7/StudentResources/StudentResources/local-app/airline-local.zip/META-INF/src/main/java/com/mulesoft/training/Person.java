package com.mulesoft.training;

public class Person {

	String firstName;
	String lastName;
	
	public Person()	{
		firstName = "Josh";
		lastName = "Rosso";
	}
	
	public String getFirstName() {
		return "HELLOOOOO";
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	
	
}
