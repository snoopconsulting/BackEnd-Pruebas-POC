package com.mulesoft.training.rest;

import java.util.ArrayList;

import org.json.JSONArray;

public interface TicketService {
	
	public String findFlight(String destination);
}
