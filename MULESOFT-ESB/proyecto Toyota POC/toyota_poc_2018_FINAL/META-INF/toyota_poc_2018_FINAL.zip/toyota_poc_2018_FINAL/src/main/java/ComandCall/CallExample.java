package ComandCall;

public class CallExample {
	
	public void methodA()
	{
		System.out.println("HELLO WORLD. THIS IS TOYOTA POC!");
	}
}

